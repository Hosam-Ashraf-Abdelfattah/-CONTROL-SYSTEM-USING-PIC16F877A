#include "control.h"

#define CARD   0x00
#define step_numb 0x01

const char* sentense[]={"close","1-Card=","2-step numb=","3-Status=","4-Stand time=","5-lock time=","6-HIGH TIME=","7-LOW TIME=","8-Light time="
"9-Safe time=","10-Key mod=","11-Conect=","12-Statues=","13-Fix="};

void first_set()
{
 unsigned char v,band;
 band=0x01;
 LCD_Clear();
 while(get_button()!='S'){
 LCD_goto_first_line();
 char * sent = sentense[1];
 LCD_write_string(sent);
 /*switch(band)
 {
  case 0x01:  LCD_write_string("1-Card=");break;
/*case 0x02:  LCD_write_string("2-step numb=");break;
  case 0x03:  LCD_write_string("3-Status=");break;
  case 0x04:  LCD_write_string("4-Stand time=");break;
  case 0x05:  LCD_write_string("5-lock time=");break;
  case 0x06:  LCD_write_string("6-HIGH TIME=");break;*/
  /*case 0x07:  LCD_write_string("7-LOW TIME=");break;
  case 0x08:  LCD_write_string("8-Light time=");break;
  case 0x09:  LCD_write_string("9-Safe time=");break;
  case 0x0A: LCD_write_string("10-Key mod=");break;
  case 0x0B: LCD_write_string("11-Conect=");break;
  case 0x0C: LCD_write_string("12-Statues=");break;
  case 0x0D: LCD_write_string("13-Fix=");break;

 }*/
 //LCD_write_string("1.Card=");
  //LCD_goto_second_line();LCD_write_string("in reset1");
 v = EEPROM_ReadByte(band);
 LCD_write_int(v+45);
 //x = get_button();
 //while(x !='E' && x !='S' && x !='+' && x !='-'){ x = get_button();}
 while(1){
        //LCD_clear_second_line();
        //LCD_write_string("in reset        ");
        //LCD_clear_second_line();LCD_DataWrite(get_button());
        unsigned char x=  get_button();
        while(x!='+'){x=  get_button();}break;
        /*if(get_button()=='+'){x='+';break;}
        else if(get_button()=='-'){x='-';LCD_goto_second_line();LCD_write_string("button press  - ");break;}
        else if(get_button()=='E'){x='E';LCD_goto_second_line();LCD_write_string("button press  E ");break;}
        else if(get_button() == 0){LCD_goto_second_line();LCD_write_string("no button press ");}*/
      }

/*if(x == '+'){band++;LCD_goto_second_line();LCD_write_string("in +");}
 else if(x == '-' && band>0x00){band--;}
 else if(x == 'E')
 {
   LCD_goto_second_line();LCD_write_string("in set");


  while(get_button()!='E')
  {
   if(get_button()=='+'){EEPROM_WriteByte(band, ++v);LCD_goto_second_line();LCD_write_int(v+45);}
   else if(get_button()=='-'){EEPROM_WriteByte(band, --v);LCD_goto_second_line();LCD_write_int(v+45);}
  }
 } */
 }
}




void first_page()
{
 //lcd write Step number =00 first line and mode right in second line
 LCD_Clear();
 LCD_goto_first_line();
 LCD_write_string("Step numb = ");
 LCD_write_string("00");
 LCD_goto_second_line();
 LCD_write_string("Mood       Right");
 //get_values();
 while(get_button()!='S');
 first_set();
}

void setting_page()
{
 LCD_Clear();
 LCD_write_string("setting");

}

/*void setting_page()
{
 unsigned char x,i=0;
 LCD_Clear();

 while(get_button()!='S'){
      LCD_write_int(EEPROM_ReadByte(i)+45);
      LCD_DataWrite('=');
      LCD_write_int(EEPROM_ReadByte(i+1));
      x=get_button();
      while(x==0);
      if (x =='E'|| x=='+'|| x=='-') {//x=get_button();
      if(x=='+'&& i<=5){i+=2;}
      else if (x=='-'&& i>=0){i-=2;}
      else if(x=='E')   //start set variable value
      {    x='5';
           LCD_goto_second_line();
           while(x!='E') // finish my setting in this point
           {
            x=get_button();
            if(x=='+'){
              LCD_goto_second_line();
              LCD_write_int(EEPROM_ReadByte(i+1));
            }

            else if(x=='-'){
              LCD_goto_second_line();
              LCD_write_int(EEPROM_ReadByte(i+1));
            }
            x=0;
           }
      }
      LCD_Clear();

      }
      }

      return;
}*/






                   /*
unsigned char * list[]={
"1-Card ="      ,
"2-step numb ="  ,
"3-Status ="      ,
4-Stand time="    ,
"5-lock time="      ,
"6-HIGH TIME="      ,
"7-LOW TIME="        ,
"8-Light time="       ,
"9-Safe time ="        ,
"10-Key mod =",
"11-Conect =",
"12-Statues=",
"13-Fix=hight-low",
"14-Park no=",
"15-Start no="  ,
"16-No now=" ,
"17-Paswoord=",
"18-Screen =",
"19-Step ="   ,
"50-Step ="};
                   */







/*void get_values()
{
   unsigned char i;
   for(i=0;i<=1;i++){
   values[i]= EEPROM_ReadByte(i);}
}

void set_values()
{
   unsigned char i;
   for(i=0;i<=1;i++){
     if(values[i]!= EEPROM_ReadByte(i)){
      EEPROM_WriteByte(i, values[i]);   }
}
}*/