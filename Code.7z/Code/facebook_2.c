

#include "LCD_module.h"
#include "buttons.h"
#include "control.h"
#include "EEPROM.h"


int main()
{

    //Buttons_init();
    LCD_initiate();
    //LCD_Clear();
    //LCD_write_int(1225) ;
    first_page();

    while(1)
    {

      LCD_write_string("done");
      break;
    }
    
    ///////////////////// test eeprom ////////

return 0;
}