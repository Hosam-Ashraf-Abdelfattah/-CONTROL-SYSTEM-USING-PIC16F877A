/*****************************************************
*Author :hosam
*Date:   7/7/2022
*Version: v02
*Brief: Buttons module
*******************************************************/
#ifndef BUTTONS_H_
#define BUTTONS_H_

#include "Utils.h"
#include "Delay.h"

#define shift_regist_tris_1 TRISC
#define shift_regist_tris_2 TRISE
#define recieve_tris_1 TRISA
#define recieve_tris_2_pin_0 TRISE
#define shift_regist_port_1 PORTC
#define shift_regist_port_2 PORTE
#define recieve_port_1 PORTA
#define recieve_port_2 PORTE

void Buttons_init() ;
unsigned char get_button()    ;

#endif