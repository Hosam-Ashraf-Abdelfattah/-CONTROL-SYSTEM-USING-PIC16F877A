/*****************************************************
*Author :hosam
*Date:   1/8/2022
*Version: v01
*Brief: DELAY module
*******************************************************/
#ifndef DELAY_H_
#define DELAY_H_
void delay(unsigned int ms);
#endif