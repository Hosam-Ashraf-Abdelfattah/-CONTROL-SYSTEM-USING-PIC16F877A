/*****************************************************
*Author :hosam
*Date:   1/8/2022
*Version: v01
*Brief: EEPROM module
*******************************************************/
#ifndef EEPROM_H_
#define EEPROM_H_

#include "Delay.h"
#include "LCD_module.h"
void EEPROM_WriteByte(unsigned char eepromAddress, unsigned char eepromData);
unsigned char EEPROM_ReadByte(unsigned char eepromAddress);
void example();

#endif