#include "LCD_module.h"

/* redesign register to become suitable for board pins */
static unsigned char arrange(char dat,char nibble)
{

  unsigned char reg = 0;
  if(nibble==1) {
  reg |= ((((1<<4)& dat)>>4)<<D4);
  reg |=  (((1<<5)& dat)>>5)<< D5;
  reg |=  (((1<<6)& dat)>>6)<< D6;
  reg |=  (((1<<7)& dat)>>7)<< D7;
  return reg;
  }
  else if(nibble==0){
  reg |= ((((1<<0)& dat)>>0)<<D4);
  reg |=  (((1<<1)& dat)>>1)<< D5;
  reg |=  (((1<<2)& dat)>>2)<< D6;
  reg |=  (((1<<3)& dat)>>3)<< D7;
  return reg;
  }
}


/* Function to send the command to LCD.
   As it is 4bit mode, a byte of data is sent in two 4-bit nibbles */
void LCD_CmdWrite(char cmd)
{
   // unsigned char first = ;
    //unsigned char second = ;
    LcdDataBus = (arrange(cmd,1) & 0x1E);     //Send higher nibble
    LcdControlBus &= ~(1<<LCD_RS); // Send LOW pulse on RS pin for selecting Command register
    LcdControlBus &= ~(1<<LCD_RW); // Send LOW pulse on RW pin for Write operation
    LcdControlBus |= (1<<LCD_EN);  // Generate a High-to-low pulse on EN pin
    delay(5);
    LcdControlBus &= ~(1<<LCD_EN);

    delay(5);


    LcdDataBus = (arrange(cmd,0) & 0x1E); //Send Lower nibble
    LcdControlBus &= ~(1<<LCD_RS);  // Send LOW pulse on RS pin for selecting Command register
    LcdControlBus &= ~(1<<LCD_RW);  // Send LOW pulse on RW pin for Write operation
    LcdControlBus |= (1<<LCD_EN);   // Generate a High-to-low pulse on EN pin
    delay(5);
    LcdControlBus &= ~(1<<LCD_EN);

    delay(5);
}

void LCD_Clear()
    {
    LCD_CmdWrite(0x00); //Clear the LCD
    LCD_CmdWrite(0x01); //Move the curser to first position
    }

/* Function to send the Data to LCD.
   As it is 4bit mode, a byte of data is sent in two 4-bit nibbles */
void LCD_DataWrite(char dat)
{   unsigned char first = arrange(dat,1);
    unsigned char second = arrange(dat,0);
    LcdDataBus = (first & 0x1E);      //Send higher nibble
    LcdControlBus |= (1<<LCD_RS);   // Send HIGH pulse on RS pin for selecting data register
    LcdControlBus &= ~(1<<LCD_RW);  // Send LOW pulse on RW pin for Write operation
    LcdControlBus |= (1<<LCD_EN);   // Generate a High-to-low pulse on EN pin
    delay(10);
    LcdControlBus &= ~(1<<LCD_EN);

    delay(5);

    LcdDataBus = (second & 0x1E);  //Send Lower nibble

    LcdControlBus |= (1<<LCD_RS);    // Send HIGH pulse on RS pin for selecting data register
    LcdControlBus &= ~(1<<LCD_RW);   // Send LOW pulse on RW pin for Write operation
    LcdControlBus |= (1<<LCD_EN);    // Generate a High-to-low pulse on EN pin
    delay(10);
    LcdControlBus &= ~(1<<LCD_EN);

    delay(5);
}

void LCD_initiate()
{

    LcdDataBusDirnReg = 0x00;  // Configure all the LCD pins as output


    LCD_CmdWrite(0x02);        // Initialize Lcd in 4-bit mode
    LCD_CmdWrite(0x28);        // enable 5x7 mode for chars
    LCD_CmdWrite(0x0E);        // Display OFF, Cursor ON
    LCD_CmdWrite(0x01);        // Clear Display
    LCD_CmdWrite(0x80);        // Move the cursor to beginning of first line

}
void LCD_goto_first_line()
{
        LCD_CmdWrite(0x80);        //Go to first line
}
void LCD_goto_second_line()
{
      LCD_CmdWrite(0xc0);        //Go to Next line
}

void LCD_clear_first_line()
{
      LCD_goto_first_line();
      LCD_write_string("                ");
      LCD_goto_first_line();
}

void LCD_clear_second_line()
{
      LCD_goto_second_line();
      LCD_write_string("                ");
      LCD_goto_second_line();
}

void LCD_write_string(char *a)
{
    char i;
    for(i=0;a[i]!=0;i++)
    {
        LCD_DataWrite(a[i]);
    }
}

void LCD_write_int(unsigned int i)     //Function to send data on LCD
{ 

unsigned int co;
unsigned char k=0;
if(i==0){LCD_DataWrite('0');}
while(i>0)
{
  if(k>3){break;}
  co+=i%10;
  i=i/10;
  if(k<3){co*=10;}
  k++;
}
k=0;
while(co>0)
{   if(k>3){break;}
    LCD_DataWrite((co%10)+48);
    co=co/10;
    k++;
}

}