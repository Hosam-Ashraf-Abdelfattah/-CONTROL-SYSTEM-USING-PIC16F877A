
#ifndef LCD_MODULE_H_
#define LCD_MODULE_H_

#include "Delay.h"

#define LcdDataBus      PORTB
#define LcdControlBus   PORTB
#define LcdDataBusDirnReg   TRISB

#define D4 4
#define D5 3
#define D6 2
#define D7 1

#define LCD_RS     7
#define LCD_RW     6
#define LCD_EN     5

//void delay(int cnt);
void LCD_CmdWrite(char cmd);
void LCD_Clear();
void LCD_DataWrite(char dat);
void LCD_goto_first_line();
void LCD_goto_second_line();
void LCD_initiate();
void LCD_write_string(char *a);
void LCD_write_int(unsigned int i) ;
void LCD_clear_first_line();
void LCD_clear_second_line();
#endif