#include "buttons.h"

void Buttons_init()
{
    ADCON1 = 0x06; // All AtoD pins on PORTA to digital
    CMCON = 0x07; // Disable Comparators
    ADCON1 = 0x07; // Make PORTA all inputs for switches
// make shift_register pins output and set first pin high and make other recive pins inputs
     //shift register tris dir output
    CLEAR_BIT(shift_regist_tris_1,2);
    CLEAR_BIT(shift_regist_tris_2,1) ;
    CLEAR_BIT(shift_regist_tris_2,2)  ;
    // make first pin of shift reg high and athors low
    SET_BIT(shift_regist_port_1,2);
    CLEAR_BIT(shift_regist_port_2,1) ;
    CLEAR_BIT(shift_regist_port_2,2) ;
    //make other recieve tris dir input
    SET_BIT(recieve_tris_1,0);
    SET_BIT(recieve_tris_1,1);
    SET_BIT(recieve_tris_1,2);
    SET_BIT(recieve_tris_1,3);
    SET_BIT(recieve_tris_1,4);
    SET_BIT(recieve_tris_1,5);
    SET_BIT(recieve_tris_2_pin_0,0);
    /*// make other recieve pins high
    PORT_SET_MASK(recieve_port_1,0xFF);//set all pins to high to be ready for getting data
    SET_BIT(recieve_port_2_pin_0,0);*/


}
unsigned char get_button()
{
    SET_BIT(shift_regist_port_1,2);
    CLEAR_BIT(shift_regist_port_2,1) ;
    CLEAR_BIT(shift_regist_port_2,2) ;
    if(recieve_port_1!=0||recieve_port_2.B0!=0)
      {    unsigned char counter = 0;
           if(GET_BIT(recieve_port_1,0)==1){delay(10);while(GET_BIT(recieve_port_1,0)==1);return '1';}
           else if(GET_BIT(recieve_port_1,1)==1){delay(10);while(GET_BIT(recieve_port_1,1)==1);return '2';}
           else if(GET_BIT(recieve_port_1,2)==1){delay(10);while(GET_BIT(recieve_port_1,2)==1);return '3';}
           else if(GET_BIT(recieve_port_1,3)==1){delay(10);while(GET_BIT(recieve_port_1,3)==1);return '-';}
           else if(GET_BIT(recieve_port_1,5)==1){delay(10);while(GET_BIT(recieve_port_1,5)==1);return '+';}
           else if(GET_BIT(recieve_port_2,0)==1){delay(10);while(GET_BIT(recieve_port_2,0)==1);return '4';}
           else if(GET_BIT(recieve_port_1,4)==1){
                  delay(10);

                  while(GET_BIT(recieve_port_1,4)==1){counter++;delay(7);}
                  if ((counter > 0)&& (counter < 100))
                  {
                  counter=0;
                   return 'E';

                  }
                  else if(counter > 100)
                  {
                  counter=0;
                  return 'S';
                  }

            }
      }
      else{return 0;}
}