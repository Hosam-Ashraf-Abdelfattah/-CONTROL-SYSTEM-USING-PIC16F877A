/*#define set 0
#define enter 1


unsigned char card = 0;
unsigned char step_numb=0;
bit status = 0;
unsigned char stand_time=0;
unsigned char lock_time=0;
unsigned char high_time=0;
unsigned char low_time=0;
unsigned char light_time=0;
unsigned char safe_time=0;
unsigned char key_mode=0
unsigned char connect=0;
unsigned char statues=0;
bit fixingroo=0;
unsigned char park_no=0;
unsigned int start_no=0;
unsigned int no_now=0;
unsigned int password =0;
unsigned char screen=0;

void start_state()
{
     LCD_write("welcome");
     LCD_CLEAR();
     volatile char get_switch = control();
     if(get_switch == set)
         {

         second_state();
         }
}
void second_state()
{
     volatile char get_choise = control();
     LCD_write_string("  ")
     LCD_write_string("1.Card = ");
     LCD_DataWrite((card+'0'));
     LCD_write_string(" >")
     while (get_choise != set)
           {
           if (get_choise == enter)
              {

              }
           }
}*/