        /*****************************************************
*Author :hosam
*Date:   21/7/2022
*Version: v01
*Brief: Control module
*******************************************************/
#ifndef CONTROL_H_
#define CONTROL_H_

#include "LCD_module.h"
#include "buttons.h"
#include "EEPROM.h"
/*extern unsigned char card ;
extern unsigned char step_numb;
extern unsigned char status1 ;
extern unsigned char stand_time;
extern unsigned char lock_time;
extern unsigned char high_time;
extern unsigned char low_time;
extern unsigned char light_time;
extern unsigned char safe_time;
extern unsigned char key_mode ;
extern unsigned char connect;
extern unsigned char statues;
extern unsigned char fixingroo;
extern unsigned char park_no;
extern unsigned int start_no;
extern unsigned int no_now;
extern unsigned int password ;
extern unsigned char screen;*/
void first_page();
void setting_page();
  
#endif